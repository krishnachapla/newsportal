<?php
session_start();
include('includes/config.php');
if(isset($_POST['submit']))
{
	
$uname=$_POST['uname'];
$pass=$_POST['pass'];

$sql = "select fullname, emailid, address, username, password from tbluser where username = '$uname' and password = '$pass'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
while($row = mysqli_fetch_assoc($result)) {
       	$_SESSION['fname'] = $row['fullname'];
		$_SESSION['email'] = $row['emailid'];
		$_SESSION['addr'] = $row['address'];
		$_SESSION['uname'] = $row['username'];
		$_SESSION['pwd'] = $row['password'];
		header("Location: index.php");
    }
} else {
    echo "<script>alert('Wrong Login Credentials. Please try again.');</script>";
}

mysqli_close($con);


}

?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>News Portal | Home Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>
  
       <!-- Page Content -->
    <div class="container">


     
      <div class="row" style="margin-top: 4%">

        <!-- Blog Entries Column -->
        <div class="col-md-8">


<?php include('includes/header.php');?>
  
 <div class="row" style="margin-top: 1%">
   <div class="col-md-8" >
   
		<div class="card my-4" style="width:500px; height:420px; margin-left:120px">
            <h5 class="card-header">Enter Login Details:</h5>
            <div class="card-body">
              <form name="Comment" method="post">
      
 <div class="form-group">
<input type="text" name="uname" class="form-control" placeholder="Enter your username" required>
</div>

 <div class="form-group">
 <input type="password" name="pass" class="form-control" placeholder="Enter your password" required>
 </div>


           
                <button type="submit" class="btn btn-primary" name="submit">Login</button>
              </form>
			  <div class="form-group" style="text-align:center">
            <br/><a href="register.php">Signup</a> <br/>
            <a  href="index.php">Home</a>
			
          </div>
            </div>
			
          </div>
	</div>
	</div>
</div>
</div>
</div>
  <?php include('includes/footer.php');?>

      <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
