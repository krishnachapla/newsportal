-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2020 at 10:29 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `newsportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE IF NOT EXISTS `tbladmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AdminUserName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `AdminEmailId` varchar(255) NOT NULL,
  `Is_Active` int(11) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `Is_Active`, `CreationDate`, `UpdationDate`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 1, '2019-12-29 12:29:33', '2019-12-29 12:29:33');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE IF NOT EXISTS `tblcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Description` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(1, 'Bollywood', 'News related to bollywood actors and movies', '2019-12-29 12:30:48', '2020-02-16 18:52:35', 1),
(2, 'Sports', 'This category consists of all sports played in India as well abroad. It covers all international sports event over the world. It is main category and can have sub categories under it. ', '2019-12-29 13:11:19', '2019-12-29 14:11:19', 1),
(3, 'Politics', 'News about national and international politics', '2020-02-16 10:54:24', NULL, 0),
(4, 'Education', 'This category contains all the post which are related to education all over the world. It is mainly related to universities and colleges', '2020-03-29 11:54:59', '2020-03-29 19:03:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE IF NOT EXISTS `tblcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postId` char(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext,
  `postingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tblcomments`
--

INSERT INTO `tblcomments` (`id`, `postId`, `name`, `email`, `comment`, `postingDate`, `status`) VALUES
(1, '1', 'Amit', 'amit@gmail.com', 'This is sample text. This is for testing purpose only', '2019-12-29 12:32:13', 1),
(2, '1', 'Priya Singh', 'itspriya@yahoo.com', 'He is premeire bowler of INDIA. Serious cause of concern.', '2020-01-27 12:58:14', 1),
(3, '1', 'Sachin Raina', 'sachinraina@gmail.com', 'Bumrah has proved that he is one of the top bowlers. Injury to him is cause of worry. Hope he recovers fast', '2020-01-27 13:08:16', 1),
(4, '2', 'Priya Singh', 'itspriya@yahoo.com', 'Good inspiration movie for mothers', '2020-02-01 11:57:44', 0),
(5, '2', 'Sakshi', 'sakshi@yahoo.com', 'Good movie for mothers who want to regain the confidence after motherhood', '2020-02-05 06:07:09', 1),
(6, '4', 'Sakshi', 'sakshi@yahoo.com', 'Not an imtiaz ali like film', '2020-02-21 10:44:27', 0),
(7, '5', 'Sakshi', 'sakshi@yahoo.com', 'Though Aditya Roy Kapur has done good acting but thehe storyline is boring.', '2020-02-21 10:53:19', 0),
(8, '5', 'Priyanka Patel', 'priyankapatel@gmail.com', 'Story is not good. Performance of Aditya and Disha is good', '2020-03-29 11:39:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE IF NOT EXISTS `tblpages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PageName` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext,
  `Description` longtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `PageTitle`, `Description`, `PostingDate`, `UpdationDate`) VALUES
(1, 'About Us', 'About News Portal', '<p><h2>About Us :&nbsp; </h2> We are leading portal in news field.</p><p><b>No. 1 : </b> portal in India</p><p><b> Awards : </b>ITA</p> \r\n<h3> Our Motto : </h3> \r\nSpeak Truth. <br/>Hear Truth. <br/>Seek Truth</h3><br/><br/>\r\n<p>IN ADDITION to presenting actual truth, we believe passionately in seeking and finding the truth behind the events and for that we go to any extent to hold the spirit of journalism.</p>\r\n', '2019-12-29 08:00:00', '2019-12-29 12:37:04'),
(2, 'Contact Us', 'Contact Us', '<h1>News Portal strives to provide the best service possible with every contact! </h1>\r\n<h3>Lets Start a Conversation</h3>\r\n\r\n<p>\r\nSometimes you need a little help from your friends. Or a News Portal support rep. Dont worry. We are her to help you.\r\n</p>\r\n<p> Feel free to contact us in case of any confusion or query </p>\r\n\r\n<p><strong>Email : contactus@np.com </strong></p>\r\n\r\n<p> For advertising queries mail us at </p><p>\r\n\r\n</p><p><strong>Email : marketing@np.com </strong></p>', '2020-01-27 13:27:55', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

CREATE TABLE IF NOT EXISTS `tblposts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PostTitle` longtext,
  `CategoryId` int(11) DEFAULT NULL,
  `SubCategoryId` int(11) DEFAULT NULL,
  `PostDetails` longtext CHARACTER SET utf8,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Is_Active` int(1) DEFAULT NULL,
  `PostUrl` mediumtext,
  `PostImage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `PostTitle`, `CategoryId`, `SubCategoryId`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`) VALUES
(1, 'Jasprit Bumrah ruled out of England T20I series due to injury', 2, 1, '<p style="margin-bottom: 15px; padding: 0px; font-size: 16px; font-family: PTSans, sans-serif;"><span style="margin: 0px; padding: 0px; font-weight: 700;">The Indian Cricket Team has received a huge blow right ahead of the commencement of the much-awaited series against England. Star speedster Jasprit Bumrah has been ruled out of the forthcoming 3-match T20I series as he suffered an injury in his left thumb.</span></p>', '2019-12-29 12:43:15', '2019-12-29 12:43:15', 1, 'Jasprit-Bumrah-ruled-out-of-England-T20I-series-due-to-injury', '6b66b461d28ebe35e35017857bec3868.jpg'),
(2, 'Panga Movie Review : An exhilarating ode to motherhood and chasing dreams', 1, 2, '<p>The screenplay that traverses through this journey of a sprightly young \r\nmother who decides to give her best shot to a second chance, is taut and\r\n wholesome, bringing out a story that is emotional, inspiring, nuanced \r\nand thoroughly engaging. The dialogues are sparkling and injected with \r\nhumour and there are some delightful touches like the school momâ€™s \r\nWhatsapp group, which finally the father becomes part of. In fact \r\nPrashantâ€™s character is also heroic in his own silent way. </p><p>The writing by Ashwiny Iyer Tiwari, Nikhil Mehrohtra and Nitesh Tiwari \r\nis brilliant and is the backbone of the film. The soulful soundtrack \r\n(music by Shankar-Ehsaan-Loy, lyrics by Javed Akhtar) is woven in so \r\nsmoothly that it never distracts yet touches the right chord.</p><p>Moving to the performances, Kangana Ranaut as Jaya is terrific and the <i>tour de force</i>\r\n of the film â€“ at home she is the gentle, dutiful Jaya who is simmering \r\nwith this latent desire to break out and catch up with her dreams. And \r\nwhen she is on the court Kangana thrills with an absolutely throbbing, \r\npulsating performance. She breathes in vulnerability and power â€“ \r\nswitching between the two facets of her character so swiftly and \r\nseamlessly that it is totally fascinating. <br><br> The support cast too\r\n pitch in ace performances â€“ Richa Chadha is superb as she gets under \r\nthe skin of her steely character and also brings in plenty of the \r\nlaughs. Jassie Gill as the supportive husband is impressive and does \r\nfull justice to a very well written role. <br></p>', '2020-02-01 11:28:41', '0000-00-00 00:00:00', 1, 'Panga-Movie-Review-:-An-exhilarating-ode-to-motherhood-and-chasing-dreams', '571b27a4b2a4c12faff43ed3bf9669dd.png'),
(3, ' Sofia Kenin, Mattek-Sands Help USA Beat Latvia to Reach Fed Cup Finals', 2, 4, 'Sofia Kenin and Bethanie Mattek-Sands defeated Jelena Ostapenko and Anastasija Sevastova 6-4, 6-0 in a deciding doubles as the USA survived a Saturday scare to beat unheralded Latvia 3-2 and reach the Fed Cup finals. New Australian Open champion Kenin and Mattek-Sands ensured the USA reached the finals in Budapest from April 14-19 after both Serena Williams and Kenin had been stunned in the singles as Latvia levelled the qualifier 2-2 in Seattle. Sevastova had earlier inflicted a shock first Fed Cup singles loss on Williams 7-6 (7/5), 3-6, 7-6 (7/4).', '2020-02-16 11:38:50', '0000-00-00 00:00:00', 1, '-Sofia-Kenin,-Mattek-Sands-Help-USA-Beat-Latvia-to-Reach-Fed-Cup-Finals', '24d4a23fc00e2f5d13e0a653f8b9e660.jpg'),
(4, 'Love Aaj Kal 2 - A Film About Confused People That Misses The Mark By A Mile', 1, 2, 'Love Aaj Kal is a confounding film about confused people. Perhaps writer-director Imtiaz Ali was attempting to have the storytelling reflect the emotions of his leads. The result is an unholy mess.\r\n\r\nThe title comes from Imitazâ€™s own 2009 film, which also features two love stories across two time zones. But the second film isnâ€™t a sequel or a reboot. It borrows the structure of the first to establish the same sentiment â€“ that the rules of engagement of romance might change with the times but the essence of love, that feeling of connection that makes life worth living, remains the same. \r\n\r\nOnce again, we have a modern couple, struggling with the complexities of relationships versus ambition. And once again, there is an older, wiser confidante and advisor Raj, who tries to steer the course of the stormy relationship between Zoe and Veer (in the first film, the advisor played by a genial Rishi Kapoor, was also named Veer).\r\n\r\nI go into every Imtiaz movie ready to be seduced by this argument and hoping that he will transport us to that sweet spot â€“ dil aur duniya ke beech. Sadly, Love Aaj Kal misses the mark by a mile.', '2020-02-18 15:57:04', '0000-00-00 00:00:00', 1, 'Love-Aaj-Kal-2---A-Film-About-Confused-People-That-Misses-The-Mark-By-A-Mile', '38ac491c2d9a6c1270aa9fac67688ff6.jpg'),
(5, 'Malang - An Average Storyline', 1, 2, 'MALANG is the story of love and revenge. Two tracks run simultaneously in the film. The flashback track shows Advait (Aditya Roy Kapur), with a disturbing family history, going to Goa for some fun. Here he bumps into Sara (Disha Patani) who has come to Goa from abroad to conquer her fears. Over drugs and running away from the police, they fall for each other. At first they decide to keep their relationship casual but things get serious. \r\n\r\nOn the whole, MALANG is high on style with good performances and thrilling moments but has an average storyline. At the box office, it only has the advantage of a clear one-week window and will therefore do average business.', '2020-02-18 16:33:44', '0000-00-00 00:00:00', 1, 'Malang---An-Average-Storyline', '58004438dc909081e0e33f9abe85ffc0.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcategory`
--

CREATE TABLE IF NOT EXISTS `tblsubcategory` (
  `SubCategoryId` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryId` int(11) DEFAULT NULL,
  `Subcategory` varchar(255) DEFAULT NULL,
  `SubCatDescription` mediumtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int(1) DEFAULT NULL,
  PRIMARY KEY (`SubCategoryId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblsubcategory`
--

INSERT INTO `tblsubcategory` (`SubCategoryId`, `CategoryId`, `Subcategory`, `SubCatDescription`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(1, 2, 'Cricket', 'It consists of news about cricket all over the world', '2020-01-20 13:49:38', '2020-03-29 19:11:52', 1),
(2, 1, 'Movie Review', 'This sub category is about the reviews of the recently released movies in INDIA and Abroad', '2020-01-27 07:07:15', '2020-02-16 18:56:38', 1),
(3, 2, 'Football', 'All Football events', '2020-02-16 09:09:46', NULL, 0),
(4, 2, 'Tennis', 'Grand Slam, ATP tour and other tennis tournaments', '2020-02-16 11:35:40', '2020-03-29 19:12:03', 1),
(5, 4, 'University Exams', 'This sub category contains the post about news related to university exams and other affiliated universities all over the world', '2020-03-29 12:09:20', '2020-03-29 19:21:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE IF NOT EXISTS `tbluser` (
  `fullname` varchar(50) NOT NULL,
  `address` varchar(350) NOT NULL,
  `emailid` varchar(60) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`emailid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`fullname`, `address`, `emailid`, `username`, `password`) VALUES
('Priya Sinha', '23, Krishna Nagar,  Station Road, Bharuch - 392001, Gujarat', 'itspriya@yahoo.com', 'itspriya', '12345'),
('Priyanka Patel', 'AA-30, RK Heights, M G Road, Bharuch - 392001', 'priyankapatel@gmail.com', 'itspriyanka', '1234567890'),
('Sachin Raina', ' F-304, R K Habitat, Bharuch', 'sachinraina@gmail.com', 'sachin12', 'sachin12'),
('Sakshi', '33, Krishna Nagar, Bharuch', 'sakshi@yahoo.com', 'sakshi', 'sakshi'),
('Shreya', 'F-333, R K habitat', 'shreya@yahoo.com', 'itsshreya', '12345');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
