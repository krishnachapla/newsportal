<?php 
session_start();
include('includes/config.php');

if(isset($_POST['submit']))
{

$email = htmlspecialchars($_POST['email']);
$name=$_POST['fname'];
$addrr=$_POST['address'];
$uname=$_POST['uname'];
$pass=$_POST['pass'];

$upd = "UPDATE tbluser SET fullname = '$name', address = '$addrr', username = '$uname', password = '$pass' WHERE emailid = '$email'";
$query=mysqli_query($con,$upd);

if($query){
  echo "<script>alert('Profile Update Successfully'); window.location = 'Login.php';</script>";
  //header("Location: Login.php");
}
 else {
 echo "<script>alert('Wrong Login Credentials. Please try again.');</script>";
 }
}
    ?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>News Portal | Home Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
	   <?php 
	   if (!isset($_SESSION['email'])) {
			include('includes/header.php');
	   }
		else{
		include('includes/header-signout.php');}
	   ?>

    <!-- Page Content -->
    <div class="container">


     
      <div class="row" style="margin-top: 4%">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

          <!-- Blog Post -->

          <!-- Pagination -->


            <h5 class="card-header">Update Profile:</h5>
            <div class="card-body">
              <form name="Comment" method="post"  >
      
	  
	  <div class="form-group">
<input type="text" name="fname" class="form-control" placeholder="Enter your fullname" value="<?php echo $_SESSION['fname'];?>" required>
</div>

 <div class="form-group">
 <textarea name="address" class="form-control" placeholder="Enter your address" rows="2" cols="200" required><?php echo $_SESSION['addr']?></textarea>
 </div>

  <div class="form-group">
<input type="email" name="email" class="form-control" placeholder="Enter your email id" value="<?php echo $_SESSION['email']?>" readonly = "true">

</div>
	  
 <div class="form-group">
<input type="text" name="uname" class="form-control" placeholder="Enter your username" value="<?php echo $_SESSION['uname']?>" required>
</div>

 <div class="form-group">
 <input type="password" name="pass" class="form-control" placeholder="Enter your password" value="<?php echo $_SESSION['pwd']?>" required>
 </div>


           
                <button type="submit" class="btn btn-primary" name="submit">Update Profile</button>
              </form>
            </div>
        </div>

        <!-- Sidebar Widgets Column -->
      <?php include('includes/sidebar.php');?>
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
      <?php include('includes/footer.php');?>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

 
</head>
  </body>

</html>
