<div style = "background-color:#6c757d; height:75px;color:white;text-align:center;" >
        <br/>Copyright &copy; NP 2020
        
        
      </div>