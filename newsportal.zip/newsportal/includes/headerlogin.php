
      <div style = "background-color:#6c757d; height:75px;margin-top: -12%">
        <a class="navbar-brand" href="index.php"><img src="images/logo.png" height="70"></a>
        
        
      </div>
  
	
	