<?php
include('includes/config.php');
$erroremail="";
if(isset($_POST['submit']))
{

$email = htmlspecialchars($_POST['email']);
$name=$_POST['fname'];
$address=$_POST['address'];
$uname=$_POST['uname'];
$pass=$_POST['pass'];


$query=mysqli_query($con,"insert into tbluser(fullname, address, emailid, username, password) values('$name','$address','$email', '$uname', '$pass')");

if($query){
  echo "<script>alert('Regisered Successfully'); window.location = 'Login.php';</script>";
  //header("Location: Login.php");
}
 else {
 echo "<script>alert('Wrong Login Credentials. Please try again.');</script>";
 }
}

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>News Portal | Home Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>
  
       <!-- Page Content -->
    <div class="container">


     
      <div class="row" style="margin-top: 4%">

        <!-- Blog Entries Column -->
        <div class="col-md-8">


<?php include('includes/header.php');?>
  
 <div class="row" style="margin-top: 1%">
   <div class="col-md-8" >
   
		<div class="card my-4" style="width:500px; margin-left:120px">
            <h5 class="card-header">Register An Account:</h5>
            <div class="card-body">
              <form name="Comment" method="post"  >
      
	  
	  <div class="form-group">
<input type="text" name="fname" class="form-control" placeholder="Enter your fullname" required>
</div>

 <div class="form-group">
 <textarea name="address" class="form-control" placeholder="Enter your address" rows="2" cols="200" required></textarea>
 </div>

  <div class="form-group">
<input type="email" name="email" class="form-control" placeholder="Enter your email id" required>

</div>
	  
 <div class="form-group">
<input type="text" name="uname" class="form-control" placeholder="Enter your username" required>
</div>

 <div class="form-group">
 <input type="password" name="pass" class="form-control" placeholder="Enter your password" required>
 </div>


           
                <button type="submit" class="btn btn-primary" name="submit">Register</button>
              </form>
            </div>
			<div class="form-group" style="text-align:center">
            <a href="Login.php">Login</a> <br/>
            <a  href="index.php">Home</a>
         </div>
            </div>
			
          </div>
	</div>
	</div>
</div>
</div>
</div>
  <?php include('includes/footer.php');?>

      <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>